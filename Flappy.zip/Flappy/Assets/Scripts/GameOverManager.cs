using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverManager : MonoBehaviour
{
    public Text scoreTxt;

    private void Start(){
        scoreTxt.text = "Your score: " + GameManager.finalScore.ToString();
    }

    public void RestartGame(){
        SceneManager.LoadScene("GameScene");
    }
}
