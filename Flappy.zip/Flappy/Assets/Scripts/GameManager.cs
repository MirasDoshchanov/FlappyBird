using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public Player birdBek;

    public static int finalScore;
    public Text scoreTxt;
    public Image tapTheScreen; 
    private int score = 0;

    private bool isGameOver = false;
    private bool gameStarted = false;

    private void Awake(){
        if (instance == null){
            instance = this;
        } else if (instance != this){
            Destroy(gameObject);
        }
    }

    private void Start(){
        tapTheScreen.gameObject.SetActive(true);

        StartCoroutine(HideTapMessageAfterTime(3f));
    }

    private void Update(){
        if (!gameStarted && Input.GetMouseButtonDown(0)){
            StartGame();
        }

        if (birdBek.isDead && !isGameOver){
            GameOver();
        }
    }

    public void StartGame(){
        tapTheScreen.gameObject.SetActive(false);
        gameStarted = true;
    }

    public void IncrementScore(){
        score++; 
        scoreTxt.text = score.ToString(); 
    }

    public void GameOver(){
        isGameOver = true;
        finalScore = score;
        SceneManager.LoadScene("GameOverScene");
    }

    public IEnumerator HideTapMessageAfterTime(float seconds){
        yield return new WaitForSeconds(seconds);
        tapTheScreen.gameObject.SetActive(false); 
    }
}
