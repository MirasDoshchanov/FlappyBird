using UnityEngine;
using UnityEngine.SceneManagement;

public class StartSceneManager : MonoBehaviour
{
    public void PlayGame(){
        SceneManager.LoadScene("GameScene"); 
    }
}
