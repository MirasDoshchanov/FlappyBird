using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacles : MonoBehaviour
{
    public float speed = 1.0f; 
    public float destroyPosition = -10.0f; 
    private bool isPassed = false; 

    private void FixedUpdate()
    {
        transform.position += (Vector3.left * speed * Time.deltaTime);

        if (transform.position.x < destroyPosition)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
{
    if (other.CompareTag("Player") && !isPassed)
    {
        isPassed = true;
        Debug.Log("Player passed obstacle! Incrementing score.");
        GameManager.instance.IncrementScore();
    }
}

}
